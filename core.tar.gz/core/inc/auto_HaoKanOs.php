<?php

//好看OS类
class HaoKanOs{
    //是否DEV服务器
    public static function IsDev(){
        if($_SERVER['SERVER_ADDR'] == '192.168.0.230' || $_SERVER['HOSTNAME']=='haokan-dev') {
            return true;
        }else{  
            return false;
        }       
    }
    //是否DEMO服务器
    public static function IsDemo(){
        if($_SERVER['SERVER_ADDR'] == '192.168.0.231' || $_SERVER['HOSTNAME'] == 'haokan-demo') {
            return true;
        }else{  
            return false;
        }       
    }
}



