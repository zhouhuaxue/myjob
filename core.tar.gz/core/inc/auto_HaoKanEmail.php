<?php

//好看Email
class HaoKanEmail{

    //系统下发邮件
    //HaoKan::Email()->SendMail(array('to'=>'litong@haokanhaokan.com','subject'=>'hi~测试','message'=>'这是个测试'))
    function SendMail($Param = array()){
        require_once('/www/core/server/email/mail.php');
        $Param['subject'] = "=?UTF-8?B?".base64_encode( $Param['subject'] )."?=";
        return HaoKanSendMail($Param);
    }

    //Smtp 发邮件
    //HaoKan::Email()->SmtpMail(array('smtpemailto'=>'litong@haokanhaokan.com','mailsubject'=>'hi~测试','mailbody'=>'这是个测试'))
    function SmtpMail($Param=array()){
        ob_start();
        require_once('/www/core/server/email/smtp.php');
        $smtpserver =$Param['smtpserver'] ? : "smtp.exmail.qq.com"; //邮箱服务器
        $smtpserverport = $Param['smtpport'] ? :25;//邮箱服务器端口 
        $smtpusermail = $Param['smtpusermail']? :"server@haokanhaokan.com"; //服务器邮箱账号
        $smtpemailto = $Param['smtpemailto']; //收件人邮箱
        $smtpuser = $Param['smtpuser'] ? : "server@haokanhaokan.com";//SMTP服务器的用户帐号 //你的邮箱账号(去掉@后面)
        $smtppass = $Param['smtppass'] ? : "haokan@123"; //SMTP服务器的用户密码 //你的邮箱密码

        $mailsubject = "=?UTF-8?B?".base64_encode( $Param['mailsubject'] )."?="; //邮件主题 
        $mailbody = $Param['mailbody']; //邮件内容 
        $mailtype = $Param['mailtype'] ? : "TXT";   //邮件格式（HTML/TXT）,TXT为文本邮件 
        $smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);  //这里面的一个true是表示使用身份验证,否则不使用身份验证. 
        $smtp->debug = false; //是否显示发送的调试信息 
        ob_get_clean();

        $smtp->log_file = '/tmp/mail.log';
        return $smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype); //发送邮件
    }


}
