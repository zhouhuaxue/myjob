<?php

//主类
class HaoKan{

    //系统
    public static function Os(){
        require_once ( dirname(__FILE__).'/auto_HaoKanOs.php' ) ;
        return new HaoKanOs();   
    }

    //邮件
    public static function Email(){
        require_once ( dirname(__FILE__).'/auto_HaoKanEmail.php' );
        return new HaoKanEmail();
    }
}

