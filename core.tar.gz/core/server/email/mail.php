<?php

function HaoKanSendMail($Param = array()){
    if (!($Param['to'] && $Param['subject'] &&$Param['message'])){
        return false;
    }
    $Param['from']?$Param['from']:$Param['from'] = 'SendMail@haokanhaokan.com';
    $Param['FromEmail']?$Param['FromEmail']:$Param['FromEmail']='SendMail@haokanhaokan.com';
    $headers  = 'MIME-Version: 1.0' . "\r\n";
    $headers .= 'Content-type: text/html; charset=utf8' . "\r\n";
    $headers .= 'From: '.$Param['from'] . "\r\n";
    return mail ($Param['to'],$Param['subject'],$Param['message'],$headers,'-f'.$Param['FromEmail']);
}