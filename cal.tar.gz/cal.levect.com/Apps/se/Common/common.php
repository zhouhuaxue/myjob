<?php
require_once(dirname(dirname(dirname(__FILE__))).'/_Public/Function/globals.php');

//Cm后台操作Url
function SeMkurl($url){
    return $url;
}

//Load 自定义类
function LoadClass($Class,$New = true) {
    $Class = trim($Class);
    if(strstr($Class,'..')){
        return false;
    }
    $Dir=dirname(APP_PATH).'/_Public/Class/class.'.$Class.'.php';
    require_once ( $Dir );
    if ($New){
        return new $Class;
    }
}

// 文件系统类
function ClassFileSys(){
    static $FileSys;
    if (is_object($FileSys)){
        return $FileSys;
    }
    $Dir = C('API_ROOT_PATH').'/api.cal.levect.com/lib/FileSys.class.php';
    require_once ( $Dir );
    $FileSys = new FileSys();
    return $FileSys;
}

// 文件系统类
function ClassPubTool(){
    static $Public;
    if (is_object($Public)){
        return $Public;
    }
    $Dir = C('API_ROOT_PATH').'/api.cal.levect.com/lib/PubTool.class.php';
    require_once ( $Dir );
    $Public = new PubTool();
    return $Public;
}

//session的Set
function SetSession($key,$val){
    if($key == null){
        $_SESSION[APP_NAME] = $val;
    }else{
        $_SESSION[APP_NAME][$key] = $val;
    }
}

//session的Get
function GetSession($key = null){
    if($key == null) {
        return $_SESSION[APP_NAME];
    }else{
        return $_SESSION[APP_NAME][$key];
    }
}


//左侧菜单数组
function LeftMenuArr(){

    return [
        [
            'base_menu' => [
                'name'=>'订阅定制',
            ],
            'second_menu' => [
                [
                    'class' => 'custom',
                    'function' => 'customgroup',
                    'name' => '分类定制',
                ],
                [
                    'class' => 'recom',
                    'function' => 'recomindex',
                    'name' => '首页推荐',
                ],
                [
                    'class' => 'recom',
                    'function' => 'pagebanner',
                    'name' => '推荐位',
                ],
            ],
        ],
        [
            'base_menu' => [
                'name'=>'订阅事件',
            ],
            'second_menu' => [
                [
                    'class' => 'calendar',
                    'function' => 'group',
                    'name' => '自有分组',
                ],
                [
                    'class' => 'opencal',
                    'function' => 'group',
                    'name' => '公共分组',
                ],
            ],
        ],
        [
            'base_menu' => [
                'name'=>'用户管理',
            ],
            'second_menu' => [
                [
                    'class' => 'usercenter',
                    'function' => 'modifypasswd',
                    'name' => '修改密码',
                ],
            ],
        ],
    ];

}


//html 路径导航
function HtmlNavBar($Data){
    $html = "<ol class='breadcrumb'>";
    $html.= "<li><a href='".SeMkurl('?m=index&a=index')."'>首页</a></li>";
    foreach ($Data as $val) {
        if ($val['url'] == '') {
            $html .= "<li class='active'>".$val['name']."</li>";
        }else{
            $html .= "<li><a href='".SeMkurl($val['url'])."'>".$val['name']."</a></li>";
        }
    }
    $html.= "</ol>";
    return $html;
}
