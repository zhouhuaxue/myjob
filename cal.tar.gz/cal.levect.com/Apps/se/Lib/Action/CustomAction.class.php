<?php
//引入用户类
$SeUser = LoadClass('SeUser',true);
//检测是否登录
$SeUser->NotLogInJump();

class CustomAction extends Action {

    public function customgroup(){

        $SeId = GetSession('SeId');
        

        $ClassSeInfo = LoadClass('SeInfo');
        $SeInfo = $ClassSeInfo->SeInfo($SeId);
        $this->assign('SeInfo',$SeInfo);

        $GroupList = M('subscribe_group')->where( "`parent_id` in ( 0 , $SeId)" )->select();
        $this->assign('GroupList',$GroupList);

        $Selected = M('se_custom')->where("`se_id` = $SeId and list_type = 'g' and `list_fid`= 0 ")->find();
        if($Selected['list_custom']){
            $CustomSelected = explode(',',$Selected['list_custom']) ;
        }else{
            $CustomSelected = array();
        }
        $this->assign('CustomSelected',$CustomSelected);
        
        $this->assign('ReloadCache',GlobalsCleanCachesUrl(
            array('act'=>'class','class'=>'Se','method'=>'SeSetListOrder','SeId'=>$SeId,'ListType'=>'g','Fid'=>'0'),
            array('act'=>'class','class'=>'SubData','method'=>'SetGroupList','SeId'=>$SeId)
        ));

        $this->display();
    }
    public function customGroupSubmit (){
        $SeId = GetSession('SeId');
        $SelectList = $_POST['SelectList'];

        if ($SelectList){
            $SeCustom=implode(',',$SelectList);
            $M = M('se_custom')->execute("replace into __TABLE__ (`se_id`,`list_type`,`list_fid`,`list_custom`) values('$SeId','g',0,'$SeCustom')");
            if ($M){
                $this->success('操作成功', SeMkurl('?m=custom&a=customgroup'));
            }else{
                $this->error('操作出错');
            }

        }else{
            $this->error('您没有选择定制的分组');
        }
    
    }





}
