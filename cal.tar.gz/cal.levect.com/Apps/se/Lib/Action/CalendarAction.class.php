<?php
//引入用户类
$SeUser = LoadClass('SeUser',true);
//检测是否登录
$SeUser->NotLogInJump();

class CalendarAction extends Action {

    function group(){
        
        $FileSys = ClassFileSys();

        $SeId = GetSession('SeId');

        $GroupList = M('subscribe_group')->where('parent_id='.$SeId)->select();

        foreach ($GroupList as &$val) {
            $val['group_icon_url'] = $FileSys->FileName2Url($val['group_icon']);
            $val['group_banner_url'] = $FileSys->FileName2Url($val['group_banner']);
        }

        $this->assign('GroupList',$GroupList);

        if ($GroupList){

            $this->display();
        }else{
            $this->error('您还没有专属分组');
        }
    
    }

    function groupedit (){
        $GroupId = $_GET['group_id'];
        
        if ( ! LoadClass('SeAuth')->CheckGroup( GetSession('SeId'), $GroupId) ){
            $this->error('您不能进行此操作');
        }
        
        $FileSys = ClassFileSys();
    
        $SubData = LoadClass('SubData');

        $GroupInfo = $SubData->GroupInfo($GroupId);

        $GroupInfo['group_icon_url'] = $FileSys->FileName2Url($GroupInfo['group_icon']);
        $GroupInfo['group_banner_url'] = $FileSys->FileName2Url($GroupInfo['group_banner']);

        $this->assign('GroupInfo',$GroupInfo);

        $this->display();
    }
    
    function groupsubmit(){
        $GroupId = (int)$_POST['group_id'];

        if ( ! LoadClass('SeAuth')->CheckGroup( GetSession('SeId'), $GroupId) ){
            $this->error('您不能进行此操作');
        }

        $GroupName = trim($_POST['group_name']);
        if (empty($GroupName)){
            $this->error('必须添加分组标题!!');
        }
        $GroupSubtitle = trim($_POST['group_subtitle']);
        $GroupDescription = trim($_POST['group_description']);
        $ParentId = GetSession('SeId');
        $data['group_id']   = $GroupId;
        $data['group_subtitle']   = $GroupSubtitle;
        $data['group_name'] = $GroupName;
        $data['group_description'] = $GroupDescription;

        if ($_FILES['group_icon']['tmp_name']){
            $FileSys = ClassFileSys();
            if( $UpFileName = $FileSys->UpLodeFile($_FILES['group_icon']) ){
                $data['group_icon'] = $UpFileName;
            }
        }
        
        if ($_FILES['group_banner']['tmp_name']){
            $FileSys = ClassFileSys();
            if( $UpFileName = $FileSys->UpLodeFile($_FILES['group_banner']) ){
                $data['group_banner'] = $UpFileName;
            }
        }

        $Aff = M('subscribe_group')->where('group_id='.$GroupId.' and parent_id = '.$ParentId )->limit(1)->save($data);
        if ($Aff > 0){
            $this->success('修改分组成功', SeMkurl('?m=calendar&a=group'));
        }else{
            $this->success('没有修改分组', SeMkurl('?m=calendar&a=group'));
        }

    }

    function item (){
        
        $GroupId = $_GET['group_id'];

        if ( ! LoadClass('SeAuth')->CheckGroup( GetSession('SeId'), $GroupId) ){
            $this->error('您不能进行此操作');
        }
        
        $FileSys = ClassFileSys();
        

        $SubData = LoadClass('SubData');

        $GroupInfo = $SubData->GroupInfo($GroupId);

        $this->assign('GroupInfo',$GroupInfo);

        $ItemList = M('subscribe_item')->where('group_id = '.$GroupId)->select();

        foreach ($ItemList as &$val) {
            $val['item_description'] = mb_substr($val['item_description'],0,10,'utf8').'...';
            $val['item_icon_url'] = $FileSys->FileName2Url($val['item_icon']);
            $val['item_banner_url'] = $FileSys->FileName2Url($val['item_banner']);
        }

        $this->assign('ItemList',$ItemList);


        $this->display();
    
    }


    //修改订阅源
    function itemedit (){

        $FileSys = ClassFileSys();

        $ItemId = $_GET['item_id'];

        if ($ItemId) {
            if ( ! LoadClass('SeAuth')->CheckItem( GetSession('SeId'), $ItemId) ){
                $this->error('您不能进行此操作');
            }
        }else{
            if ( ! LoadClass('SeAuth')->CheckGroup( GetSession('SeId'), $_GET['group_id']) ){
                $this->error('您不能进行此操作');
            }
        
        }

        if ($ItemId) {

            $ItemInfo = M('subscribe_item')->where('`item_id`='.$ItemId)->limit(1)->find();

            $ItemInfo['item_icon_url'] = $FileSys->FileName2Url($ItemInfo['item_icon']);

            $ItemInfo['item_banner_url'] = $FileSys->FileName2Url($ItemInfo['item_banner']);

            $this->assign('ItemInfo',$ItemInfo);

            $this->assign('PageTitle','修改订阅源');
        }else{

            $this->assign('PageTitle','添加订阅源');
        }

        $GroupId = $ItemInfo['group_id'] ? $ItemInfo['group_id'] : $_GET['group_id'];

        $SubData = LoadClass('SubData');

        $GroupInfo = $SubData->GroupInfo($GroupId);

        $this->assign('GroupInfo',$GroupInfo);

        $this->display();
    
    }
    
    //item修改(添加)
    function itemsubmit (){
        $FileSys = ClassFileSys();

        $ItemId = $_POST['item_id'];

        if ($ItemId) {
            if ( ! LoadClass('SeAuth')->CheckItem( GetSession('SeId'), $ItemId) ){
                $this->error('您不能进行此操作');
            }
        }
        if($_POST['group_id']){
            if ( ! LoadClass('SeAuth')->CheckGroup( GetSession('SeId'), $_POST['group_id']) ){
                $this->error('您不能进行此操作');
            }
        }

        $data['item_name'] = trim($_POST['item_name']);
        if (empty($data['item_name'])){
            $this->error('必须添加订阅源标题');
        }
        $data['item_subtitle'] = trim($_POST['item_subtitle']);
        $data['item_description'] = trim($_POST['item_description']);
        if($_FILES['item_icon']['tmp_name']){
            if( $UpFileName = $FileSys->UpLodeFile($_FILES['item_icon']) ){
                $data['item_icon'] = $UpFileName;
            }
        }
        if($_FILES['item_banner']['tmp_name']){
            if ($UpFileName = $FileSys->UpLodeFile($_FILES['item_banner']) ){
                $data['item_banner'] = $UpFileName;
            }
        }

        if ( $data != array_filter($data) ){
            $this->error('参数不全');
        }
        $data['is_remind'] = $_POST['is_remind'] ? 1 : 0;
        $data['is_permanent'] = $_POST['is_permanent'] ? 1 : 0;
        
        if ($ItemId){ // add
            $Aff = M('subscribe_item')->where('item_id='.$ItemId)->limit(1)->save($data);
            if ($Aff > 0){
                $this->success('修改分组成功', SeMkurl('?m=calendar&a=item&group_id='.$_POST['group_id']));
            }else{
                $this->error('修改分组失败');
            }
        
        }else{
            $data['group_id'] = $_POST['group_id'];
            $InsId = M('subscribe_item')->add($data);
            if($InsId){
                $this->success('新增订阅源成功', SeMkurl('?m=calendar&a=item&group_id='.$data['group_id']));
            }else{
                $this->error('新增订阅源失败');
            }

        }

    }


    function event(){
        
        $ClassPubTool = ClassPubTool();
        
        $FileSys = ClassFileSys();

        $ItemId = $_GET['item_id'];
        
        if ( ! LoadClass('SeAuth')->CheckItem( GetSession('SeId'), $ItemId) ){
            $this->error('您不能进行此操作');
        }
        
        $SubData = LoadClass('SubData');

        $ItemInfo = $SubData->ItemInfo($ItemId);

        $this->assign('ItemInfo',$ItemInfo);

        $GroupId = $ItemInfo['group_id'];
        
        $GroupInfo = $SubData->GroupInfo($GroupId);

        $this->assign('GroupInfo',$GroupInfo);
        
        $SelectDate = $_GET['selectdate'] ? $_GET['selectdate'] : date('Ym');
        $TodayDate = date('Ym');



        $YearStart = substr($SelectDate,0,4);

        $UrlList['Select'] = '<b>'.$YearStart.'年</b>&nbsp;&nbsp;';

        for ($i = 101;$i <= 112;$i++){
            $t = $YearStart.substr($i,-2);
            if ($t == $SelectDate) {
                $UrlList['Select'] .= '<a href="#" class="btn btn-primary btn-xs disabled" role="button">'.substr($i,-2).'月</a>';
            }else{
                $Url = SeMkurl('?m=calendar&a=event&item_id='.$ItemId.'&selectdate='.$t);
                $UrlList['Select'] .= '<a href="'.$Url.'" class="btn btn-primary btn-xs" role="button">'.substr($i,-2).'月</a>';
            }
            $UrlList['Select'] .="&nbsp;";
        }



        $UrlList['preday']=SeMkurl('?m=calendar&a=event&item_id='.$ItemId.'&selectdate='.$ClassPubTool->PreMonth($SelectDate.'01','Ym'));
        $UrlList['today']=SeMkurl('?m=calendar&a=event&item_id='.$ItemId.'&selectdate='.$TodayDate);
        $UrlList['nexday']=SeMkurl('?m=calendar&a=event&item_id='.$ItemId.'&selectdate='.$ClassPubTool->NextMonth($SelectDate.'01','Ym'));

        $this->assign('UrlList',$UrlList);
        
        $this->assign('SelectDate',$SelectDate);

        $MaxDate = date('t', strtotime($SelectDate.'01'));

        $AllDateArray = array();
        for ($i = 101; $i <= $MaxDate+100;$i++ ){
            $tmp = $ClassPubTool->DateFormatToCalDate( $SelectDate.substr($i,-2) ) ;
            $AllDateArray = array_merge($AllDateArray,array_values($tmp));
        }
        $AllDateStr = '"'.implode ('","',array_unique ($AllDateArray)).'"';
        
        $starttime = date('Y-m-d',strtotime($SelectDate.'01'));
        $endtime = substr($starttime,0,-2).date('t',strtotime($starttime));

        $where = '`item_id`= '.$ItemId.'  and `starttime` <= "'.$endtime.'" and `endtime` >= "'.$starttime.'" and `event_date` in ('.$AllDateStr.')';
        $EventList = M('subscribe_event')->where($where)->order("`event_id` desc")->select();
        foreach ($EventList as &$val){
            $val['event_showtime'] = $ClassPubTool->DateFormatToCn($val['event_repeat'],$val['event_time']);
            $val['event_icon_url'] = $FileSys->FileName2Url($val['event_icon']);
            $val['event_description'] = str_replace("\n",'<br/>',$val['event_description']);
            
            $s1 = strpos($val['event_description'],'<br/>' );
            $shot = substr ( $val['event_description'], 0 , $s1);
            $s2 = strpos(substr($val['event_description'],$s1+5),'<br/>' );
            if($s2 === false) {
                $shot = $val['event_description'];
            }else{
                $shot .="<br/>".substr ( $val['event_description'], $s1+5 , $s2);
            }
            $val['event_description_shot'] = $shot;
        }
        
        $this->assign('EventList',$EventList);

        $this->display();
    
    }

    //修改(新建)事件
    function eventedit (){
        $FileSys = ClassFileSys();
        $PubTool = ClassPubTool();
        $ItemId = $_GET['item_id'];
        $EventId = $_GET['event_id'];

        if ($EventId){
            if ( ! LoadClass('SeAuth')->CheckEvent( GetSession('SeId'), $EventId) ){
                $this->error('您不能进行此操作');
            }
        }

        if ($ItemId){
            if ( ! LoadClass('SeAuth')->CheckItem( GetSession('SeId'), $ItemId) ){
                $this->error('您不能进行此操作');
            }
        }

        $EventRepeat = array('N'=>'单次','Y'=>'年重复', 'M'=>'月重复', 'D'=>'日重复', 'W'=>'周重复');
        $this->assign('EventRepeat',$EventRepeat);

        $ItemInfo = M('subscribe_item')->where("`item_id` = $ItemId")->limit(1)->find();
        $this->assign('ItemInfo',$ItemInfo);

        $GroupInfo = M('subscribe_group')->where("`group_id`=".$ItemInfo['group_id'])->find();
        $this->assign('GroupInfo',$GroupInfo);

        if($EventId){
            $this->assign('PageTitle','修改事件');
        }else{
            $this->assign('PageTitle','添加事件');
        }

        if ($EventId){
            $EventInfo = M('subscribe_event')->where("`event_id` = ".$EventId)->find();
            $EventInfo['event_icon_url'] = $FileSys->FileName2Url($EventInfo['event_icon']);
            
            $END = $PubTool->CalDateDeFormat($EventInfo['event_time']);
            $EventInfo['event_date'] = $END['date'];
            $EventInfo['event_time'] = $END['time'];

            $this->assign('EventInfo',$EventInfo);
        }

        $this->display();
    
    }


    //事件提交
    function eventsubmit(){
        $EventId = $_POST['event_id'];
        if ( $EventId && ! LoadClass('SeAuth')->CheckEvent( GetSession('SeId'), $EventId) ){
            $this->error('您不能进行此操作');
        }

        $FileSys = ClassFileSys();

        $EventName=$_POST['event_name'];
        $EventAddress = $_POST['event_address'];
        $EventDescription = $_POST['event_description'];
        $EventRepeat = $_POST['event_repeat'];
        
        $Starttime = $_POST['starttime'];
        $Endtime = $_POST['endtime'];

        $DataOri = $_POST['event_data'][$EventRepeat] or '';

        $PubTool = ClassPubTool();
        $DateBase10 = $PubTool->RepeatDate2Base10($EventRepeat,$DataOri);
        if($DateBase10 === false){
            $this->error('事件日期不正确');
        }
        $EventData = $PubTool->Base10to62($DateBase10);

        $EventTime = $PubTool->CalDateFormat($DataOri,$_POST['event_time']);
        $ItemId = $_POST['item_id'];
        $EventType = $_POST['event_type'];

        $EventUrl = trim($_POST['event_url']);

        if( $UpFileName = $FileSys->UpLodeFile($_FILES['event_icon']) ){
            $EventIcon = $UpFileName;
        }

        $InsData = array(
            'item_id'=>$ItemId,
            'event_name'=>$EventName,
            'event_address'=>$EventAddress,
            'event_description'=>$EventDescription,
            'event_icon'=>$EventIcon,
            'starttime'=>$Starttime,
            'endtime'=>$Endtime,
            'event_date'=>$EventData,
            'event_repeat'=>$EventRepeat,
            'event_time'=>$EventTime,
            'event_type'=>$EventType,
            'event_url'=>$EventUrl,
        );

        if ($EventId > 0){
            $InsData = array_filter($InsData);
            $InsData['event_date'] = $EventData;
            if ( M('subscribe_event')->where("`event_id` = ".$EventId )->limit(1)->save($InsData) ){
                $this->success('修改成功',SeMkurl("?m=calendar&a=event&item_id=".$ItemId));
            }else{
                $this->success('没有进行修改',SeMkurl("?m=calendar&a=event&item_id=".$ItemId));
            }
        }else{
            $InsId = M('subscribe_event')->add(array_filter($InsData));
            if($InsId){
                $this->success('添加成功',SeMkurl("?m=calendar&a=event&item_id=".$ItemId));
            }else{
                $this->success('添加失败');
            }
        }
    }

    //删除事件
    function eventdel (){
        $EventId = $_GET['event_id'];
        if ( ! LoadClass('SeAuth')->CheckEvent( GetSession('SeId'), $EventId) ){
            $this->error('您不能进行此操作');
        }
        if ( M('subscribe_event')->where("`event_id` = $EventId")->limit(1)->delete() ){
            $this->success();
        }else{
            $this->error();
        }
    }


}
