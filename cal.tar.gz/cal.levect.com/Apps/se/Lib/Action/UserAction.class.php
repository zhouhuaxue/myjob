<?php
//用户页面
class UserAction extends Action {

    //登入页
    public function login(){
        //载入用户类
        $SeUser = LoadClass('SeUser',true);
        //如果登录状态就跳首页
        if ( $SeUser -> isLogin() ) {
            header('Location:'.SeMkurl('?m=index&a=index'));
            exit;
        }
        
        $AjaxLoginUrl = SeMkurl('?m=ajax&a=login');
        $this->assign('AjaxLoginUrl',$AjaxLoginUrl);

        $this->display();

    }

    //登出页
    public function logout(){
        $SeUser = LoadClass('SeUser',true);
        $SeUser->logOut();
        header('Location:'.SeMkurl('?m=user&a=login'));
    }
}
