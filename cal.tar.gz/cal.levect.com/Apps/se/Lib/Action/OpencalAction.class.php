<?php
//引入用户类
$SeUser = LoadClass('SeUser',true);
//检测是否登录
$SeUser->NotLogInJump();

class OpencalAction extends Action {

    function group(){
        
        $FileSys = ClassFileSys();

        $SeId = GetSession('SeId');

        $GroupList = M('subscribe_group')->where('parent_id=0')->select();

        foreach ($GroupList as &$val) {
            $val['group_icon_url'] = $FileSys->FileName2Url($val['group_icon']);
            $val['group_banner_url'] = $FileSys->FileName2Url($val['group_banner']);
        }

        $this->assign('GroupList',$GroupList);

        if ($GroupList){

            $this->display();
        }else{
            $this->error('您还没有专属分组');
        }
    
    }
    
    function item (){
        
        $GroupId = $_GET['group_id'];

        $FileSys = ClassFileSys();

        $SubData = LoadClass('SubData');

        $GroupInfo = $SubData->GroupInfo($GroupId);

        if ($GroupInfo['parent_id'] !== '0') {
            $this->error('你不能进行此操作');
        }

        $this->assign('GroupInfo',$GroupInfo);

        $ItemList = M('subscribe_item')->where('group_id = '.$GroupId)->select();

        foreach ($ItemList as &$val) {
            $val['item_description'] = mb_substr($val['item_description'],0,10,'utf8').'...';
            $val['item_icon_url'] = $FileSys->FileName2Url($val['item_icon']);
            $val['item_banner_url'] = $FileSys->FileName2Url($val['item_banner']);
        }

        $this->assign('ItemList',$ItemList);


        $this->display();
    
    }

    function event(){
        
        $ClassPubTool = ClassPubTool();
        
        $FileSys = ClassFileSys();

        $ItemId = $_GET['item_id'];
        
        $SubData = LoadClass('SubData');

        $ItemInfo = $SubData->ItemInfo($ItemId);

        $this->assign('ItemInfo',$ItemInfo);

        $GroupId = $ItemInfo['group_id'];
        
        $GroupInfo = $SubData->GroupInfo($GroupId);
        
        if ($GroupInfo['parent_id'] !== '0') {
            $this->error('你不能进行此操作');
        }

        $this->assign('GroupInfo',$GroupInfo);
        
        $SelectDate = $_GET['selectdate'] ? $_GET['selectdate'] : date('Ym');
        $TodayDate = date('Ym');

        $YearStart = substr($SelectDate,0,4);

        $UrlList['Select'] = '<b>'.$YearStart.'年</b>&nbsp;&nbsp;';

        for ($i = 101;$i <= 112;$i++){
            $t = $YearStart.substr($i,-2);
            if ($t == $SelectDate) {
                $UrlList['Select'] .= '<a href="#" class="btn btn-primary btn-xs disabled" role="button">'.substr($i,-2).'月</a>';
            }else{
                $Url = SeMkurl('?m=opencal&a=event&item_id='.$ItemId.'&selectdate='.$t);
                $UrlList['Select'] .= '<a href="'.$Url.'" class="btn btn-primary btn-xs" role="button">'.substr($i,-2).'月</a>';
            }
            $UrlList['Select'] .="&nbsp;";
        }


        $UrlList['preday']=SeMkurl('?m=opencal&a=event&item_id='.$ItemId.'&selectdate='.$ClassPubTool->PreMonth($SelectDate.'01','Ym'));
        $UrlList['today']=SeMkurl('?m=opencal&a=event&item_id='.$ItemId.'&selectdate='.$TodayDate);
        $UrlList['nexday']=SeMkurl('?m=opencal&a=event&item_id='.$ItemId.'&selectdate='.$ClassPubTool->NextMonth($SelectDate.'01','Ym'));




        $this->assign('UrlList',$UrlList);
        
        $this->assign('SelectDate',$SelectDate);

        $MaxDate = date('t', strtotime($SelectDate.'01'));

        $AllDateArray = array();
        for ($i = 101; $i <= $MaxDate+100;$i++ ){
            $tmp = $ClassPubTool->DateFormatToCalDate( $SelectDate.substr($i,-2) ) ;
            $AllDateArray = array_merge($AllDateArray,array_values($tmp));
        }
        $AllDateStr = '"'.implode ('","',array_unique ($AllDateArray)).'"';
        
        $starttime = date('Y-m-d',strtotime($SelectDate.'01'));
        $endtime = substr($starttime,0,-2).date('t',strtotime($starttime));

        $where = '`item_id`= '.$ItemId.'  and `starttime` <= "'.$endtime.'" and `endtime` >= "'.$starttime.'" and `event_date` in ('.$AllDateStr.')';
        $EventList = M('subscribe_event')->where($where)->order("`event_id` desc")->select();
        foreach ($EventList as &$val){
            $val['event_showtime'] = $ClassPubTool->DateFormatToCn($val['event_repeat'],$val['event_time']);
            $val['event_icon_url'] = $FileSys->FileName2Url($val['event_icon']);

            $val['event_description'] = str_replace("\n",'<br/>',$val['event_description']);

            $s1 = strpos($val['event_description'],'<br/>' );
            $shot = substr ( $val['event_description'], 0 , $s1);
            $s2 = strpos(substr($val['event_description'],$s1+5),'<br/>' );
            if($s2 === false) {
                $shot = $val['event_description'];
            }else{
                $shot .="<br/>".substr ( $val['event_description'], $s1+5 , $s2);
            }
            $val['event_description_shot'] = $shot;
        }
        
        $this->assign('EventList',$EventList);

        $this->display();
    
    }
}
