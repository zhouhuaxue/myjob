<?php
if ( HaoKan::Os()->IsDev() ){
    return array(
        //'配置项'=>'配置值'
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => '192.168.0.31', // 服务器地址
        'DB_NAME'   => 'calendar', // 数据库名
        'DB_USER'   => 'root', // 用户名
        'DB_PWD'    => '123', // 密码
        'DB_PORT'   => 3306, // 端口
        'DB_PREFIX' => 'cal_', // 数据库表前缀
        'TMPL_PARSE_STRING'=> array (
            '__STATICURL__' => 'http://cal.dev.levect.com/static', //静态域名
            '__APPCNNAME__' => '好看日历后台', //App名称
        ),
        'API_ROOT_PATH' => dirname(dirname(dirname(dirname(dirname(__FILE__))))),
        //默认错误跳转对应的模板文件
        'TMPL_ACTION_ERROR' => 'Public/error',
        //默认成功跳转对应的模板文件
        'TMPL_ACTION_SUCCESS' => 'Public/success',
        'API_URL'    => 'http://api.cal.dev.levect.com/',
        'DOMAIN_URL' => 'http://cal.dev.levect.com/se/',
    );

}elseif ( HaoKan::Os()->IsDemo() ){
    return array(
        //'配置项'=>'配置值'
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => '192.168.0.31', // 服务器地址
        'DB_NAME'   => 'calendar', // 数据库名
        'DB_USER'   => 'root', // 用户名
        'DB_PWD'    => '123', // 密码
        'DB_PORT'   => 3306, // 端口
        'DB_PREFIX' => 'cal_', // 数据库表前缀
        'TMPL_PARSE_STRING'=> array (
            '__STATICURL__' => 'http://cal.demo.levect.com/static', //静态域名
            '__APPCNNAME__' => '好看日历后台', //App名称
        ),
        'API_ROOT_PATH' => dirname(dirname(dirname(dirname(dirname(__FILE__))))),
        //默认错误跳转对应的模板文件
        'TMPL_ACTION_ERROR' => 'Public/error',
        //默认成功跳转对应的模板文件
        'TMPL_ACTION_SUCCESS' => 'Public/success',
        'API_URL'    => 'http://api.cal.demo.levect.com/',
        'DOMAIN_URL' => 'http://cal.demo.levect.com/se/',
    );

}else{
    return array(
        //'配置项'=>'配置值'
        'DB_TYPE'   => 'mysql', // 数据库类型
        'DB_HOST'   => 'rdsqjynaieqmu2y.mysql.rds.aliyuncs.com', // 服务器地址
        'DB_NAME'   => 'calendar', // 数据库名
        'DB_USER'   => 'calendar', // 用户名
        'DB_PWD'    => 'RbJDeDGdywEXAwdT', // 密码
        'DB_PORT'   => 3306, // 端口
        'DB_PREFIX' => 'cal_', // 数据库表前缀
        'TMPL_PARSE_STRING'=> array (
            '__STATICURL__' => 'http://cal.levect.com/static', //静态域名
            '__APPCNNAME__' => '好看日历后台', //App名称
        ),
        'API_ROOT_PATH' => dirname(dirname(dirname(dirname(dirname(__FILE__))))),
        //默认错误跳转对应的模板文件
        'TMPL_ACTION_ERROR' => 'Public/error',
        //默认成功跳转对应的模板文件
        'TMPL_ACTION_SUCCESS' => 'Public/success',
        'API_URL'    => 'http://api.cal.levect.com/',
        'DOMAIN_URL' => 'http://cal.levect.com/se/',
    );
}
