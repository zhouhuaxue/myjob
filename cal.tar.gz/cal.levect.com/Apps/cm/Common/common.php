<?php
require_once(dirname(dirname(dirname(__FILE__))).'/_Public/Function/globals.php');

//Cm后台操作Url
function CmMkurl($url){
    return $url;
}

//Load 自定义类
function LoadClass($Class,$New = true) {
    $Class = trim($Class);
    if(strstr($Class,'..')){
        return false;
    }
    $Dir=dirname(APP_PATH).'/_Public/Class/class.'.$Class.'.php';
    require_once ( $Dir );
    if ($New){
        return new $Class;
    }
}

// 文件系统类
function ClassFileSys(){
    static $FileSys;
    if (is_object($FileSys)){
        return $FileSys;
    }
    $Dir = C('API_ROOT_PATH').'/api.cal.levect.com/lib/FileSys.class.php';
    require_once ( $Dir );
    $FileSys = new FileSys();
    return $FileSys;
}

// 文件系统类
function ClassPubTool(){
    static $Public;
    if (is_object($Public)){
        return $Public;
    }
    $Dir = C('API_ROOT_PATH').'/api.cal.levect.com/lib/PubTool.class.php';
    require_once ( $Dir );
    $Public = new PubTool();
    return $Public;
}

//session的Set
function SetSession($key,$val){
    if($key == null){
        $_SESSION[APP_NAME] = $val;
    }else{
        $_SESSION[APP_NAME][$key] = $val;
    }
}

//session的Get
function GetSession($key = null){
    if($key == null) {
        return $_SESSION[APP_NAME];
    }else{
        return $_SESSION[APP_NAME][$key];
    }
}


//左侧菜单数组
function LeftMenuArr(){

    return [
        [
            'base_menu' => [
                'name'=>'日历管理',
            ],
            'second_menu' => [
                [
                    'class' => 'calendar',
                    'function' => 'group',
                    'name' => '订阅管理',
                ],
                [
                    'class' => 'recommend',
                    'function' => 'index',
                    'name' => '推荐管理',
                ],
                [
                    'class' => 'recommend',
                    'function' => 'recomindex',
                    'name' => '首页推荐',
                ],
                [
                    'class'=>'constitute' ,
                    'function'=>'index',
                    'name'=>'事件成员',
                ],
            ],
        ],
        [
            'base_menu' => [
                'name'=>'厂商管理',
            ],
            'second_menu' => [
                [
                    'class' => 'se',
                    'function' => 'index',
                    'name' => '厂商列表',
                ],
                [
                    'class' => 'se',
                    'function' => 'user',
                    'name' => '厂商用户',
                ],
            ],
        ],
        /*
        [
            'base_menu' => [
                'name'=>'订阅数据',
            ],
            'second_menu' => [
                [
                    'class' => 'aaa',
                    'function' => 'bbb',
                    'name' => '第二季3',
                ],
                [
                    'class' => 'aaa',
                    'function' => 'bbb',
                    'name' => '第二季4',
                ],
            ],
        ],*/
        [
            'base_menu' => [
                'name'=>'模拟器',
            ],
            'second_menu' => [
                [
                    'class' => 'simulator',
                    'function' => 'calendar',
                    'name' => '日历模拟',
                ],
                [
                    'class' => 'simulator',
                    'function' => 'api',
                    'name' => '接口模拟',
                ],
            ],
        ],
        [
            'base_menu' => [
                'name'=>'用户管理',
            ],
            'second_menu' => [
                [
                    'class' => 'usercenter',
                    'function' => 'modifypasswd',
                    'name' => '修改密码',
                ],
            ],
        ],
    ];

}


//html 路径导航
function HtmlNavBar($Data){
    $html = "<ol class='breadcrumb'>";
    $html.= "<li><a href='".CmMkurl('?m=index&a=index')."'>首页</a></li>";
    foreach ($Data as $val) {
        if ($val['url'] == '') {
            $html .= "<li class='active'>".$val['name']."</li>";
        }else{
            $html .= "<li><a href='".CmMkurl($val['url'])."'>".$val['name']."</a></li>";
        }
    }
    $html.= "</ol>";
    return $html;
}
