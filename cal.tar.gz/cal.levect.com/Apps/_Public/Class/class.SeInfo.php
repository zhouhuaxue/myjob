<?php

class SeInfo{

    function SeInfo($SeId){
        if (!$SeId){
            return false;
        }
        return M('se_info')->where('se_id = '.$SeId)->find();   
    }




}
