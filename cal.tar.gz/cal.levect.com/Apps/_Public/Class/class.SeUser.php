<?php
require_once(dirname(__FILE__).'/'.'class.iUser.php');
require_once(dirname(__FILE__).'/'.'class.User.php');

//SE User 编辑后台用户
class SeUser extends User implements iUser{

    //判断用户名密码是否匹配
    public function checkUserPasswd ( $UserName,$PassWord ) {
        if (empty($UserName) || empty($PassWord)){
            return false;
        }
        $PassWord = parent::MkPasswd($PassWord);
        $One = M('se_user')->field("`user_id`")->where("`user_name` = '$UserName' and `user_passwd` = '$PassWord'")->limit(1)->find();
        //echo M()->getlastsql();
        if ($One['user_id'] > 0) {
            return $One['user_id'];
        }else{
            return false;
        }
    }

    //修改密码
    public function ModifyPasswd ($UserName, $PassWord, $Force = false,$OriPasswd=''){
        if ( $Force == false && !$this->checkUserPasswd($UserName, $OriPasswd) ) {
            return false;
        }
        $PassWord = parent::MkPasswd($PassWord);
        $Data = array('user_passwd'=>$PassWord);
        if ( M('se_user')->where("`user_name` = '{$UserName}'")->limit(1)->Save($Data) ) {
            return true;
        }else{
            return false;
        }
    }

    //判断是否登录状态
    public function isLogIn (){
        return parent::isLogIn();
    }

    //登录
    public function setLogIn($UserId,$Remember=false){
        $UserInfo = $this->userInfo($UserId);
        if ($UserInfo){
            SetSession('SeId',$UserInfo['se_id']);
            $SeInfo = LoadClass('SeInfo',true)->SeInfo($UserInfo['se_id']);
            SetSession('SeName',$SeInfo['se_name']);
            return parent::setLogIn($UserId,$Remember);
        }else{
            return false;
        }
    }

    //退出
    public function logOut(){
        return parent::logOut();
    }
    
    //用户信息
    public function userInfo($UserId){
        $One = M('se_user')->where("`user_id` = $UserId")->limit(1)->find();
        return $One;
    }

    //没有登录自动处理
    public function NotLogInJump(){
        $Url=SeMkurl('?m=user&a=login');
        if (!self::isLogIn()){ //没有登录
            return parent::NotLogInJump($Url);
        }
        if( GetSession('SeId') < 1000 ) { //厂商错误
            return parent::NotLogInJump($Url);
        }
    }

    

}
