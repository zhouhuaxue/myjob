<?php
require_once(dirname(__FILE__).'/'.'class.iUser.php');
require_once(dirname(__FILE__).'/'.'class.User.php');

//CM User 编辑后台用户
class CmUser extends User implements iUser{

    //判断用户名密码是否匹配
    public function checkUserPasswd ( $UserName,$PassWord ) {
        if (empty($UserName) || empty($PassWord)){
            return false;
        }
        $PassWord = parent::MkPasswd($PassWord);
        $One = M('cm_user')->field("`user_id`")->where("`user_name` = '$UserName' and `user_passwd` = '$PassWord'")->limit(1)->find();
        //echo M()->getlastsql();
        if ($One['user_id'] > 0) {
            return $One['user_id'];
        }else{
            return false;
        }
    }
    //修改密码
    public function ModifyPasswd ($UserName, $PassWord, $Force = false,$OriPasswd=''){
        if ( $Force == false && !$this->checkUserPasswd($UserName, $OriPasswd) ) {
            return false;
        }
        $PassWord = parent::MkPasswd($PassWord);
        $Data = array('user_passwd'=>$PassWord);
        if ( M('cm_user')->where("`user_name` = '{$UserName}'")->limit(1)->Save($Data) ) {
            return true;
        }else{
            return false;
        }

    }

    //判断是否登录状态
    public function isLogIn (){
        return parent::isLogIn();
    }

    //登录
    public function setLogIn($UserId,$Remember=false){
        return parent::setLogIn($UserId,$Remember);
    }

    //退出
    public function logOut(){
        return parent::logOut();
    }
    
    //用户信息
    public function userInfo($UserId){
        $One = M('cm_user')->where("`user_id` = $UserId")->limit(1)->find();
    }

    //没有登录自动处理
    public function NotLogInJump(){
        if (!self::isLogIn()){
            $Url=CmMkurl('?m=user&a=login');
            return parent::NotLogInJump($Url);
        }
    }

    

}
