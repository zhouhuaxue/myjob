<?php

//用户操作接口

interface iUser {

    //判断用户名密码是否匹配
    public function checkUserPasswd($UserName,$PassWord);

    //修改密码
    public function ModifyPasswd($UserName,$PassWord,$Force=false,$OriPasswd='');

    //判断是否登录
    public function isLogIn();

    //登录动作
    public function setLogIn($UserId,$Remember=false);

    //退出
    public function logOut ();

    //用户信息
    public function userInfo($UserId);

    //未登录跳转
    public function NotLogInJump();



}
