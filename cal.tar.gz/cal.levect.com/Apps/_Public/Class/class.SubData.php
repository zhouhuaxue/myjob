<?php

class SubData {

    function GroupInfo($GroupId){
        if ($GroupId < 1){
            return false;
        }
        $GroupInfo = M('subscribe_group')->where("`group_id` = $GroupId")->find();
        return $GroupInfo;
    }
    

    function ItemInfo($ItemId){
        if ($ItemId < 1){
            return false;
        }
        $ItemInfo = M('subscribe_item')->where("`item_id` = $ItemId")->find();
        return $ItemInfo;
    }

    function EventInfo($EventId){
        if ($EventId < 1){
            return false;
        }
        $EventInfo = M ('subscribe_event')->where("`event_id` = $EventId")->find();
        return $EventInfo;
    }


    function UpdateTime($Type,$Id){
        if ($Type == 'event') {
            $this->UpEvent($Id);
            $EventInfo = $this->EventInfo($Id);
            $this->UpItem($EventInfo['item_id']);
            $ItemInfo = $this->ItemInfo($EventInfo['item_id']);
            $this->UpGroup($ItemInfo['group_id']);
        }elseif($Type == 'item') {
            $this->UpItem($Id);
            $ItemInfo = $this->ItemInfo($Id);
            $this->UpGroup($ItemInfo['group_id']);
        }elseif($Type == 'group'){
            $this->UpGroup($Id);
        }
    }

    function UpEvent($Id){
        if($Id < 1){
            return false;
        }
        $Res = M('subscribe_event')->where('event_id = '.$Id)->limit(1)->save(array('lastupdate'=>date('Y-m-d H:i:s')));
        return $Res ? true : false;
    }

    function UpItem($Id){
        if($Id < 1){
            return false;
        }
        $Res = M('subscribe_item')->where('item_id = '.$Id)->limit(1)->save(array('lastupdate'=>date('Y-m-d H:i:s')));
        return $Res ? true : false;
    }

    function UpGroup($Id){
        if($Id < 1){
            return false;
        }
        $Res = M('subscribe_group')->where('group_id = '.$Id)->limit(1)->save(array('lastupdate'=>date('Y-m-d H:i:s')));
        return $Res ? true : false;
    }











}
