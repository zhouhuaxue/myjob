<?php

include(dirname(__FILE__).'/class.SubData.php');

class SeAuth {

    private $SubData;

    function __construct() {
        $this->SubData = new SubData();
    }

    function CheckGroup($SeId,$GroupId){
        if ($SeId < 1 || $GroupId < 1){
            return false;
        }
        $GroupInfo = $this->SubData->GroupInfo($GroupId);
        if ($GroupInfo['parent_id'] == $SeId) {
            return true;
        }else{
            return false;
        }
    }

    function CheckItem($SeId,$ItemId){
        if ($SeId < 1 || $ItemId < 1){
            return false;
        }
        $ItemInfo = $this->SubData->ItemInfo($ItemId);
        if ($ItemInfo) {
            return $this-> CheckGroup ( $SeId ,$ItemInfo['group_id'] );
        }else{
            return false;
        }
    }

    function CheckEvent($SeId,$EventId){
        if($SeId < 1 || $EventId < 1) {
            return false;
        }
        $EventInfo = $this->SubData->EventInfo($EventId);
        if ($EventInfo) {
            return $this->CheckItem($SeId,$EventInfo['item_id']);
        }else{
            return false;
        }
    }


    //验证是否可以继续推荐
    function CheckSeRecom($SeId,$RecPos,$ItemId=0){
        $ItemId = $ItemId ? $ItemId : 0;
        if ($RecPos == 'i' && $ItemId == 0){
            return false;
        }

        $now = date("Y-m-d H:i:s");
        $Count = M('subscribe_recommend')->where("rec_from=$SeId and rec_pos='$RecPos' and item_id= $ItemId and rec_start < '$now' and rec_end > '$now' ")->count();
        if ( $Count < 2 ) {
            return true;
        }else{
            return false;
        }
    }



}
