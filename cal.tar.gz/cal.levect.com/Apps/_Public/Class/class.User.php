<?php

//用户父类
class User {

    //密码加密方法
    function MkPasswd( $OriPasswd ){
        if(empty($OriPasswd)){
            return false;
        }
        $Md5 = md5('#$%^&'.$OriPasswd.'TN$%^)(*');
        return substr( $Md5 , 16) . substr ( $Md5,0,16);
    }

    //判断是否登录
    public function isLogIn (){
        if ( GetSession('UserId') > 0 ) {
            return true;
        }else{
            return false;
        }
    }

    //登录
    public function setLogIn($UserId,$Remember=false){
        SetSession('UserId',$UserId);
        if ($Remember == true){
        
        }
    }

    //退出
    public function logOut(){
        SetSession(null,null);
    }

    //未登录跳转
    public function NotLogInJump($Url){
        header('Location:'.$Url);
        exit;
    }

}
