<?php

//清空多缓存组件
function GlobalsCleanCachesUrl(){
    $Ajax = '';
    $ArgsCount = count(func_get_args());
    foreach(func_get_args() as $val) {
        $Url = C('DOMAIN_URL');
        $Url.="?m=ajax&a=CleanCache";
        if ( in_array ($val['act'] , array( 'func','class','key' ) ) ){
            $Url .='&act='.$val['act'];
        }else{
            return '';
        }
        unset ($val['act']);
        $post = http_build_query($val);
        $Id = "Rund".time().rand(1000,9999);
        $Ajax .= '
        $.ajax({ 
            type: "POST", 
            url: "'.$Url.'", 
            data: "'.$post.'",
            success: function(msg){
                num++ ; 
                if(num == '.$ArgsCount.'){ 
                    alert("操作成功");
                }
            }
        })';
    }

    $Return = <<<EOF
    <button type="button" class="btn btn btn-danger" id="$Id">立即生效</button>
    <script>
        var num = 0;
        $(document).ready(function() {
            $('#$Id').click(function(){
                if (!confirm('刷新前请先提交页面数据!如已提交请继续.')) {
                    return ;
                }
                $Ajax
            });
        });
    </script>
EOF;
    return $Return;
}

//清空缓存组件
function GlobalsCleanCacheUrl($Act='func',$Param = array()){
    $Url = C('DOMAIN_URL');
    $Url.="?m=ajax&a=CleanCache";
    if ( in_array ($Act , array( 'func','class','key' ) ) ){
        $Url .='&act='.$Act;
    }else{
        return '';
    }
    $post = http_build_query($Param);
    $Id = "Rund".time().rand(1000,9999);
    $Return = <<<EOF
    <button type="button" class="btn btn btn-danger" id="$Id">立即生效</button>
    <script>
        $(document).ready(function() {
            $('#$Id').click(function(){
                if (!confirm('刷新前请先提交页面数据!如已提交请继续.')) {
                    return ;
                }
                $.ajax({
                   type: "POST",
                   url: "$Url",
                   data: "$post",
                   success: function(msg){
                        if(msg==1){
                            alert('操作成功');
                        }else{
                            alert('操作失败');
                        }
                   }
                });
            });
        });
    </script>
EOF;
    return $Return;

}
