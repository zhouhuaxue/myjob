<?php
header("Content-type: text/html; charset=utf-8"); 
//项目名称
define('APP_NAME', 'CalCm');
//项目路径
define('APP_PATH', '../../../Apps/cm/');

//调试模式
if ( HaoKan::Os()->IsDev() || HaoKan::Os()->IsDemo ) {
    define('APP_DEBUG', true);
}else{
    define('APP_DEBUG', false);
}

//框架入口
require '../../../../../core/ThinkPHP/ThinkPHP.php';
