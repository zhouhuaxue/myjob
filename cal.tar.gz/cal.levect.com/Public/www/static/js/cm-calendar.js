$(document).ready(function() {
    $('#GroupOrderSave').click(function(){
        $.ajax({
            type: "POST",
            url: "some.php",
            data: $('#GroupForm').serialize(),
            success: function(msg){
                alert( "Data Saved: " + msg );
            }
        });
        
        
    });
});
