$(document).ready(function(){
    if($(".sidebar .active")){
        $(".sidebar .active").closest("ul").show();
    }
});

var Accordion = function(el, multiple) {
    this.el = el || {};
    this.multiple = multiple;
    // Variables privadas
    var links = this.el.find('.link');
    // Evento
    links.on('click', {el: this.el, multiple: this.multiple}, this.dropdown);
}

Accordion.prototype.dropdown = function(e) {
    var $el = e.data.el;
    var	$this = $(this);
    var	$next = $this.next();

    $next.slideToggle();
    $this.parent().toggleClass('open');

    if (!e.data.multiple) {
        $el.find('.submenu').not($next).slideUp().parent().removeClass('open');
    };
}
var accordion = new Accordion($('#accordion'), false);

//菜单绑定事件一级菜单是button,二级菜单是a
$(".sidebar [menu]").on("click",function(){
    window.location.href = "?m="+$(this).attr("menu")+"&a="+$(this).attr("second");
});